const build = require('./build')

build({ output: './src/common/emoji-mart-vue/data/all.json' })