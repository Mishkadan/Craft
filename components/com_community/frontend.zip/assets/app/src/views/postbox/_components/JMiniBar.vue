<template>
    <nav class="joms-postbox-tab">
        <slot></slot>
    </nav>
</template>

<script>
export default {

}
</script>

<style lang="scss">
.joms-postbox-tab {
    .joms-list li {
        user-select: none;
    }
}
</style>
